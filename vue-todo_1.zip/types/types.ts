export interface IForm {
    title: string,
    desc: string
}

export interface ITodoList {
    title: string,
    desc: string,
    id: string | number
}